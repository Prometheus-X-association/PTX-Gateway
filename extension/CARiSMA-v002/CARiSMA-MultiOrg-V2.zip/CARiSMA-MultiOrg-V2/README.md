# CARiSMA multi-organization demo prototype

A static web prototype for presenting CARiSMA assessment results for several organizations. It has two pages:

- **Admin view** (`TAI-CARiSMA.html`) shows every check and all of its evidence.
- **Client view** (`TAI-CARiSMA-client.html`) shows the checks that passed: INFO (default CARiSMA check) and WARNING (passed with a clarification to the use case owner).

> **Demo data only.** Every organization in `organizations.json` is fictional, and every report and diagram is synthetic. Use this project for UI demonstration and integration testing only. It is not compliance or security assessment evidence.

## Project structure

```text
CARiSMA-MultiOrg/
├── TAI-CARiSMA.html          # Admin view (self-contained: inline CSS + JS)
├── TAI-CARiSMA-client.html   # Client view (self-contained: inline CSS + JS)
├── organizations.json        # Organization registry
├── reports/                  # One CARiSMA result JSON per organization
│   ├── report-scenario_analysis (UML2)-20261113-105925.json   # HeadAI (supplied report)
│   └── report-org-001.json … report-org-005.json               # synthetic demo reports, same structure
└── diagrams/                 # One system/process diagram per organization
    └── org-001-diagram.png … org-005-diagram.png
```

There are no build steps and no external JavaScript files. Both pages load `organizations.json` and then fetch the report and diagram of the selected organization.

## Run locally

From the `CARiSMA-MultiOrg` directory, run:

```bash
python -m http.server 8000
```

Then open one of these pages:

- Admin: <http://localhost:8000/TAI-CARiSMA.html>
- Client: <http://localhost:8000/TAI-CARiSMA-client.html>

Do not open the HTML files with `file://`, because browsers block the JSON fetches.

To use another registry file, add `?registry=` to the URL, for example `TAI-CARiSMA.html?registry=my-orgs.json`.

## Pages

### Shared

- **Service offering tabs.** Each tab shows the offering name, with "by ⟨organization⟩" underneath and a *Demo* badge when `demo` is `true`. The selected offering's name is the page title, and the offering organization appears in the subtitle, the metadata, the diagram title and the check detail panel. If the tabs do not fit, they scroll horizontally. A shadow at either edge shows that more tabs are available. The tabs also work with the mouse wheel and the arrow, Home and End keys.
- **Tab transition.** When you switch tabs, the content swipes left or right. If the viewer's system is set to reduced motion, the content switches without animation.
- **Use case in the header.** Both pages show the use case under the page title in the top bar. It is the same for all organizations and links to its page, which opens in a new tab.
- **Interactive diagram.** You can zoom and pan the diagram.
- **Printing.** The pages have no print button. When printed from the browser (Ctrl+P / Cmd+P), the top bar, filters, diagram controls and detail panel are hidden.

### Admin view (`TAI-CARiSMA.html`)

- **Outcome donut.** It shows the INFO, WARNING and FAILED shares, with "checks passed" (INFO + WARNING, for example `9/10`) in the centre and "checks executed" (for example `10/10 checks executed`) below it. The legend lists each count and its percentage, and the counts add up to the total.
- **Summary cards.** They show executed, INFO, WARNING and failed checks. The FAILED segment, legend row and card appear only when the report contains failed checks.
- **Check cards and panel.** Each check shows the original `status` and `success` values from the report.
- **Check list.** It contains every check and can be searched and filtered by status. Each card shows a one-line summary (the first finding, or the result for INFO checks) and the number of INFO, WARNING and ERROR messages.
- **Evidence panel.** Selecting a check opens a panel that groups every message by its role, and each message keeps its own status badge:
  - **Analysis scope:** INFO messages that describe the model, for example "Your model contains 1 ML Model(s)…"
  - **Findings:** WARNING and ERROR messages before the clarification
  - **Clarification to the use case owner:** the messages after "The check did not pass, however there is a comment on the check:". That line is quoted above them.
  - **Result:** INFO messages that start with `=>`, for example "=> No vulnerabilities … detected."
- **Context.** The page also shows assessment coverage, information about the tool, and the credential ID.

### Client view (`TAI-CARiSMA-client.html`)

- **Compact execution card.** It contains:
  - a ring that shows how many checks passed (INFO + WARNING, for example `9/10`)
  - a caption that shows how many checks were executed (for example "10/10 checks executed")
  - two equal tiles: **Passed** (INFO) and **Passed with clarification** (WARNING), with a short legend explaining each
- **Passed checks.** INFO and WARNING checks with `success: true` are listed together and can be filtered by *All*, *Passed* or *With clarification*. Each card shows:
  - INFO: the result message from the report
  - WARNING: the clarification to the use case owner
- **Evidence panel.** Selecting a card opens it. For WARNING checks it shows the clarification first. Below that come the analysis scope, the findings addressed by the clarification, and the result. The report line "The check did not pass, however…" is not repeated here.
- Failed checks are not shown on this page, and the page does not refer to them or to the admin view. A difference between "passed" and "executed" in the ring is the only sign that a check did not pass.

## How results are interpreted

| Report value | Meaning in the UI |
| --- | --- |
| The check appears in `checks[]` | The check was **executed**. Every check in the report counts as executed, whatever its result. |
| `success: true`, `status: "INFO"` (or no `status`) | **Passed**: a default CARiSMA check passed. |
| `success: true`, `status: "WARNING"` | **Passed with clarification**: the scanner raised a finding, and a clarification was given to the use case owner. In the report, the clarification is the text after "The check did not pass, however there is a comment on the check:". |
| `success: false` (any `status`), or `status: "ERROR"` | The check **failed**: it was executed but did not pass. Only the admin view lists failed checks. The client view does not show or mention them; they only reduce its "passed" count. |

So executed = INFO + WARNING + FAILED, and passed = INFO + WARNING. A report cannot show a check that never ran, because such a check is not in `checks[]`.

Both pages display the CARiSMA report exactly as supplied. Neither page edits the report or stores any decisions.

### Demo data coverage

The synthetic reports cover different combinations of check results and message statuses, for testing both pages:

| Report | Profile | Passed / total | Combinations covered |
| --- | --- | --- | --- |
| `report-org-001.json` | Mostly passed with clarification | 9/10 | `success:false` + `ERROR`; a clarified WARNING check whose findings mix WARNING and ERROR messages |
| `report-org-002.json` | Two failures | 8/10 | `success:false` + `WARNING` (with an ERROR message on the marker line); `success:true` + `ERROR` |
| `report-org-003.json` | All passed | 10/10 | No failed checks; a clarification made of INFO messages |
| `report-org-004.json` | Many failures | 5/10 | `success:false` + `ERROR`; `success:false` + `INFO` (check could not be evaluated); `success:false` with no `status` |
| `report-org-005.json` | Mixed | 8/10 | `success:false` + `ERROR` with no messages; `success:true` + `ERROR`; mixed WARNING/ERROR findings |

## Configuration

### `organizations.json`

```json
{
  "schemaVersion": "1.0",
  "useCaseName": "Trustworthy AI service assessment",
  "useCaseUrl": "https://example.org/use-cases/trustworthy-ai-assessment",
  "organizations": [
    {
      "id": "org-001",
      "organizationName": "Northstar Labs",
      "offeringName": "Northstar Semantic AI",
      "type": "AI service provider",
      "reportFile": "reports/report-org-001.json",
      "diagramFile": "diagrams/org-001-diagram.png",
      "description": "Synthetic assessment and illustration for testing the admin and client UI.",
      "demo": true
    }
  ]
}
```

Top-level fields apply to all organizations:

| Field | Required | Purpose |
| --- | --- | --- |
| `useCaseName` | no | The name of the use case, shown in the header of both pages. If it is missing, the header shows "Not specified". |
| `useCaseUrl` | no | The link for the use case. Only `http` and `https` URLs become links; otherwise the header shows only the name. |
| `organizations` | yes | The list of service offerings, one tab each. |

Fields for each organization:

| Field | Required | Purpose |
| --- | --- | --- |
| `id` | yes | A unique identifier, also used in the credential ID. |
| `offeringName` | yes | The name of the service or offering (for example "Digital Twin Builder"). It is the tab label, the page title and the "Service offering" field. The older `name` field is still accepted as a fallback. |
| `organizationName` | recommended | The organization that offers the service. It is shown as "by …" under each tab and as "Offered by" on both pages. |
| `type` | no | The organization type, shown below the tabs. |
| `description` | no | A short description, shown below the tabs. |
| `reportFile` | yes | The path to the CARiSMA result JSON. |
| `diagramFile` | yes | The path to the diagram image. |
| `demo` | no | `true` labels the assessment as demonstration data. |

The use case name and the `example.org` URL are placeholders.

### Report files

The pages read these fields from each report:

- `name` (the model name)
- `success`
- `checks[]`, where each check has `name`, `status`, `success` and `messages[]`
- `messages[]`, where each message is an object `{ "message": "…", "status": "INFO" | "WARNING" | "ERROR" }`. Plain strings are still accepted; their status is then guessed from their position.
- `reports.XML` (optional)

When displayed, literal `\n` and `\uXXXX` sequences in messages are decoded, and hard-wrapped lines are rejoined. A line break is kept only where a sentence ends and the next line starts a new one. The report files are not changed.

If `reports.XML` is present, the pages use its `<Timestamp>` as the analysis date and its `<CheckResult>` messages as the evidence messages. Otherwise, the pages look for a `YYYYMMDD-HHMMSS` timestamp in the report file name.

## Replacing the demo data with real reports

1. Copy the CARiSMA result JSON files into `reports/` and the diagram images into `diagrams/`.
2. In `organizations.json`, set the top-level `useCaseName` and `useCaseUrl`, and add or edit one record per organization.
3. Set `"demo": false` for real assessments.
4. Reload the pages. No HTML changes are needed.

## Deployment limitation

This is a static frontend prototype with no authentication. Showing different content on the admin and client pages does not restrict access. Anyone who can reach the server can request any report JSON directly. Restrict access on the server before you use real assessment data.
