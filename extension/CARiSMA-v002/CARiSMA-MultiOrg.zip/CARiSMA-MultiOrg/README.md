# CARiSMA multi-organization demo prototype

A static web prototype for presenting CARiSMA assessment results for several organizations. It has two pages:

- **Admin view** (`TAI-CARiSMA.html`) shows every check and all of its evidence.
- **Client view** (`TAI-CARiSMA-client.html`) shows the checks that passed: INFO (default CARiSMA check) and WARNING (passed with a clarification to the use case owner).

> **Demo data only.** Every organization in `organizations.json` is fictional, and every report and diagram is synthetic. Use this project for UI demonstration and integration testing only. It is not compliance or security assessment evidence.

## Project structure

```text
CARiSMA-MultiOrg/
├── TAI-CARiSMA.html          # Admin view (self-contained: inline CSS + JS)
├── TAI-CARiSMA-client.html   # Client view (self-contained: inline CSS + JS)
├── organizations.json        # Organization registry
├── reports/                  # One CARiSMA result JSON per organization
│   └── report-org-001.json … report-org-005.json
└── diagrams/                 # One system/process diagram per organization
    └── org-001-diagram.png … org-005-diagram.png
```

There are no build steps and no external JavaScript files. Both pages load `organizations.json` and then fetch the report and diagram of the selected organization.

## Run locally

From the `CARiSMA-MultiOrg` directory, run:

```bash
python -m http.server 8000
```

Then open one of these pages:

- Admin: <http://localhost:8000/TAI-CARiSMA.html>
- Client: <http://localhost:8000/TAI-CARiSMA-client.html>

Do not open the HTML files with `file://`, because browsers block the JSON fetches.

To use another registry file, add `?registry=` to the URL, for example `TAI-CARiSMA.html?registry=my-orgs.json`.

## Pages

### Shared

- **Organization tabs.** If the tabs do not fit, they scroll horizontally. A shadow at either edge shows that more tabs are available. The tabs also work with the mouse wheel and the arrow, Home and End keys.
- **Tab transition.** When you switch tabs, the content swipes left or right. If the viewer's system is set to reduced motion, the content switches without animation.
- **Use case in the header.** Both pages show the use case under the page title in the top bar. It is the same for all organizations and links to its page, which opens in a new tab.
- **Interactive diagram.** You can zoom and pan the diagram.
- **Print / Save PDF.**

### Admin view (`TAI-CARiSMA.html`)

- **Outcome donut.** It shows the INFO, WARNING and FAILED shares, with "checks executed" (for example `10/10`) in the centre. The legend lists each count and its percentage.
- **Summary cards.** They show executed, INFO, WARNING and failed checks. The FAILED segment, legend row and card appear only when the report contains failed checks.
- **Check list.** It contains every check and can be searched and filtered by status. Selecting a check opens a panel with all evidence messages, including findings and provider explanations.
- **Context.** The page also shows assessment coverage, information about the tool, and the credential ID.

### Client view (`TAI-CARiSMA-client.html`)

- **Compact execution card.** It contains:
  - a ring that shows how many checks were executed (for example `10/10`)
  - two equal tiles: **Passed** (INFO) and **Passed with clarification** (WARNING), with a short legend explaining each
- **Passed checks.** INFO and WARNING checks with `success: true` are listed together and can be filtered by *All*, *Passed* or *With clarification*. Each card shows:
  - INFO: the result message from the report
  - WARNING: the clarification to the use case owner
- **Evidence panel.** Selecting a card opens it. For WARNING checks it shows the clarification first, followed by all evidence messages.
- Failed checks are not shown on this page. For the full findings, refer to the admin view.

## How results are interpreted

| Report value | Meaning in the UI |
| --- | --- |
| `checks[].success === true` | The check **executed** successfully. This does not mean the check passed. |
| `checks[].status === "INFO"` (with `success: true`) | **Passed**: a default CARiSMA check passed. |
| `checks[].status === "WARNING"` (with `success: true`) | **Passed with clarification**: the scanner raised a finding, and a clarification was given to the use case owner. In the report, the clarification is the text after "The check did not pass, however there is a comment on the check:". |
| `success === false` and no `status` | The check **failed**. Only the admin view shows failed checks. |

Both pages display the CARiSMA report exactly as supplied. Neither page edits the report or stores any decisions.

## Configuration

### `organizations.json`

```json
{
  "schemaVersion": "1.0",
  "useCaseName": "Trustworthy AI service assessment",
  "useCaseUrl": "https://example.org/use-cases/trustworthy-ai-assessment",
  "organizations": [
    {
      "id": "org-001",
      "name": "Northstar Semantic AI (Demo)",
      "type": "AI service provider",
      "reportFile": "reports/report-org-001.json",
      "diagramFile": "diagrams/org-001-diagram.png",
      "description": "Synthetic assessment and illustration for testing the admin and client UI.",
      "demo": true
    }
  ]
}
```

Top-level fields apply to all organizations:

| Field | Required | Purpose |
| --- | --- | --- |
| `useCaseName` | no | The name of the use case, shown in the header of both pages. If it is missing, the header shows "Not specified". |
| `useCaseUrl` | no | The link for the use case. Only `http` and `https` URLs become links; otherwise the header shows only the name. |
| `organizations` | yes | The list of organizations, one tab each. |

Fields for each organization:

| Field | Required | Purpose |
| --- | --- | --- |
| `id` | yes | A unique identifier, also used in the credential ID. |
| `name` | yes | The label of the tab and the subject service name. |
| `type` | no | The organization type, shown below the tabs. |
| `reportFile` | yes | The path to the CARiSMA result JSON. |
| `diagramFile` | yes | The path to the diagram image. |
| `demo` | no | `true` labels the assessment as demonstration data. |

The use case name and the `example.org` URL are placeholders.

### Report files

The pages read these fields from each report:

- `name` (the model name)
- `success`
- `checks[]`, where each check has `name`, `status`, `success` and `messages[]`
- `reports.XML` (optional)

If `reports.XML` is present, the pages use its `<Timestamp>` as the analysis date and its `<CheckResult>` messages as the evidence messages. Otherwise, the pages look for a `YYYYMMDD-HHMMSS` timestamp in the report file name.

## Replacing the demo data with real reports

1. Copy the CARiSMA result JSON files into `reports/` and the diagram images into `diagrams/`.
2. In `organizations.json`, set the top-level `useCaseName` and `useCaseUrl`, and add or edit one record per organization.
3. Set `"demo": false` for real assessments.
4. Reload the pages. No HTML changes are needed.

## Deployment limitation

This is a static frontend prototype with no authentication. Showing different content on the admin and client pages does not restrict access. Anyone who can reach the server can request any report JSON directly. Restrict access on the server before you use real assessment data.
